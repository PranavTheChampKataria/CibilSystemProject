<?php
	$hostname="localhost";
	$username="root";
	$password="";
	$db="cibil_system_project";
	$conn=mysqli_connect($hostname, $username, $password, $db);
?>


